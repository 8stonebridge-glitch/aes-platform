import { describe, it, expect } from "vitest";
import { enrichBridgeWithMath } from "../src/bridge/bridge-enricher.js";
import type { ConfidenceDimensions } from "../src/engines/confidence-engine.js";
import type { VetoInput } from "../src/engines/veto-engine.js";

function makeCleanVetoInput(): VetoInput {
  return {
    confidence_composite: 0.8,
    confidence_dimensions: { evidence: 0.8, deps: 0.8 },
    has_critical_contradictions: false,
    contradiction_count: 0,
    bridge_age_days: 1,
    max_bridge_age_days: 30,
    unresolved_dependencies: 0,
    scope_violations: [],
    missing_acceptance_tests: 0,
    total_acceptance_tests: 10,
    validator_failures: [],
    auth_defined: true,
    role_boundary_defined: true,
    tenancy_boundary_defined: true,
    destructive_actions_scoped: true,
    payment_reconciliation_defined: true,
    admin_role_bounded: true,
    external_api_fallback_defined: true,
    realtime_offline_defined: true,
    auditable_actions_logged: true,
    data_mutation_ownership_defined: true,
    all_feature_deps_exist: true,
  };
}

function makeDimensions(value = 0.8): ConfidenceDimensions {
  return {
    evidence_coverage: value,
    dependency_completeness: value,
    pattern_match_quality: value,
    test_coverage: value,
    freshness: value,
    contradiction_penalty: value,
  };
}

describe("enrichBridgeWithMath", () => {
  it("returns all math fields", () => {
    const result = enrichBridgeWithMath({
      confidence_dimensions: makeDimensions(),
      veto_input: makeCleanVetoInput(),
      dependency_completeness: 1.0,
      freshness: 0.9,
      priority_rank: 1,
      max_files: 10,
      max_lines: 500,
      current_state: "validated",
    });
    expect(result.confidence_score).toBeGreaterThan(0);
    expect(result.risk_score).toBeLessThan(1);
    expect(result.freshness_score).toBe(0.9);
    expect(result.dependency_score).toBe(1.0);
    expect(result.scope_budget.max_files).toBe(10);
    expect(result.scope_budget.max_lines).toBe(500);
    expect(result.priority_rank).toBe(1);
    expect(result.artifact_state).toBe("validated");
    expect(result.last_math_evaluation).toBeTruthy();
  });

  it("risk_score is inverse of confidence", () => {
    const result = enrichBridgeWithMath({
      confidence_dimensions: makeDimensions(1.0),
      veto_input: makeCleanVetoInput(),
      dependency_completeness: 1.0,
      freshness: 1.0,
      priority_rank: 1,
      max_files: 10,
      max_lines: 500,
      current_state: "raw",
    });
    expect(result.confidence_score + result.risk_score).toBeCloseTo(1.0, 2);
  });

  it("captures veto state", () => {
    const vetoInput = makeCleanVetoInput();
    vetoInput.auth_defined = false;
    const result = enrichBridgeWithMath({
      confidence_dimensions: makeDimensions(),
      veto_input: vetoInput,
      dependency_completeness: 1.0,
      freshness: 0.9,
      priority_rank: 1,
      max_files: 10,
      max_lines: 500,
      current_state: "validated",
    });
    expect(result.veto_state.any_triggered).toBe(true);
    expect(result.veto_state.blocking_codes).toContain("VETO_AUTH_NOT_DEFINED");
  });

  it("sets drift_threshold to 0.1", () => {
    const result = enrichBridgeWithMath({
      confidence_dimensions: makeDimensions(),
      veto_input: makeCleanVetoInput(),
      dependency_completeness: 1.0,
      freshness: 0.9,
      priority_rank: 1,
      max_files: 10,
      max_lines: 500,
      current_state: "validated",
    });
    expect(result.drift_threshold).toBe(0.1);
  });

  it("produces valid ISO timestamp", () => {
    const result = enrichBridgeWithMath({
      confidence_dimensions: makeDimensions(),
      veto_input: makeCleanVetoInput(),
      dependency_completeness: 1.0,
      freshness: 0.9,
      priority_rank: 1,
      max_files: 10,
      max_lines: 500,
      current_state: "raw",
    });
    const date = new Date(result.last_math_evaluation);
    expect(isNaN(date.getTime())).toBe(false);
  });
});
