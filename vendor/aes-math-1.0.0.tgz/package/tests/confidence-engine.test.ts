import { describe, it, expect } from "vitest";
import {
  computeConfidence,
  computeEvidenceCoverage,
  computeDependencyCompleteness,
  computeFreshness,
  computeTestCoverage,
  computeContradictionPenalty,
  CONFIDENCE_THRESHOLDS,
} from "../src/engines/confidence-engine.js";

describe("computeConfidence", () => {
  it("returns high composite for all-perfect dimensions", () => {
    const result = computeConfidence({
      evidence_coverage: 1.0,
      dependency_completeness: 1.0,
      pattern_match_quality: 1.0,
      test_coverage: 1.0,
      freshness: 1.0,
      contradiction_penalty: 1.0,
    });
    expect(result.composite).toBe(1.0);
    expect(result.meets_promotion).toBe(true);
    expect(result.meets_auto_approve).toBe(true);
    expect(result.warnings).toHaveLength(0);
    expect(result.blockers).toHaveLength(0);
  });

  it("blocks when any dimension is zero", () => {
    const result = computeConfidence({
      evidence_coverage: 0,
      dependency_completeness: 0.8,
      pattern_match_quality: 0.8,
      test_coverage: 0.8,
      freshness: 0.8,
      contradiction_penalty: 0.8,
    });
    expect(result.blockers.length).toBeGreaterThan(0);
    expect(result.meets_promotion).toBe(false);
    expect(result.meets_auto_approve).toBe(false);
  });

  it("generates warnings for dimensions below 0.50", () => {
    const result = computeConfidence({
      evidence_coverage: 0.4,
      dependency_completeness: 0.9,
      pattern_match_quality: 0.9,
      test_coverage: 0.9,
      freshness: 0.9,
      contradiction_penalty: 0.9,
    });
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings[0]).toContain("evidence_coverage");
  });

  it("generates blockers for dimensions below 0.30", () => {
    const result = computeConfidence({
      evidence_coverage: 0.2,
      dependency_completeness: 0.9,
      pattern_match_quality: 0.9,
      test_coverage: 0.9,
      freshness: 0.9,
      contradiction_penalty: 0.9,
    });
    expect(result.blockers.length).toBeGreaterThan(0);
    expect(result.meets_promotion).toBe(false);
  });

  it("computes weighted average correctly", () => {
    const result = computeConfidence({
      evidence_coverage: 0.5,
      dependency_completeness: 0.5,
      pattern_match_quality: 0.5,
      test_coverage: 0.5,
      freshness: 0.5,
      contradiction_penalty: 0.5,
    });
    expect(result.composite).toBe(0.5);
  });

  it("rejects invalid dimension values", () => {
    expect(() => computeConfidence({
      evidence_coverage: 1.5,
      dependency_completeness: 0.5,
      pattern_match_quality: 0.5,
      test_coverage: 0.5,
      freshness: 0.5,
      contradiction_penalty: 0.5,
    })).toThrow();
  });

  it("meets bridge approval but not promotion at 0.68", () => {
    const result = computeConfidence({
      evidence_coverage: 0.7,
      dependency_completeness: 0.7,
      pattern_match_quality: 0.6,
      test_coverage: 0.7,
      freshness: 0.7,
      contradiction_penalty: 0.7,
    });
    expect(result.composite).toBeGreaterThanOrEqual(CONFIDENCE_THRESHOLDS.bridge_approval_minimum);
    expect(result.meets_bridge_approval).toBe(true);
  });
});

describe("computeEvidenceCoverage", () => {
  it("returns 0 for zero claims", () => {
    expect(computeEvidenceCoverage({ total_claims: 0, evidenced_claims: 0, source_count: 5, min_sources: 3 })).toBe(0);
  });

  it("returns high score for full coverage", () => {
    const score = computeEvidenceCoverage({ total_claims: 10, evidenced_claims: 10, source_count: 5, min_sources: 3 });
    expect(score).toBeGreaterThan(0.9);
  });
});

describe("computeDependencyCompleteness", () => {
  it("returns 1.0 for zero dependencies", () => {
    expect(computeDependencyCompleteness({ total_dependencies: 0, resolved_dependencies: 0, blocked_dependencies: 0 })).toBe(1.0);
  });

  it("returns 0 when blocked", () => {
    expect(computeDependencyCompleteness({ total_dependencies: 5, resolved_dependencies: 4, blocked_dependencies: 1 })).toBe(0);
  });
});

describe("computeFreshness", () => {
  it("returns 1.0 for brand new artifact", () => {
    const now = new Date();
    expect(computeFreshness({ artifact_created_at: now, evidence_max_age_days: 30, now })).toBe(1.0);
  });

  it("returns 0 for expired artifact", () => {
    const now = new Date();
    const old = new Date(now.getTime() - 31 * 24 * 60 * 60 * 1000);
    expect(computeFreshness({ artifact_created_at: old, evidence_max_age_days: 30, now })).toBe(0);
  });
});

describe("computeTestCoverage", () => {
  it("returns 1.0 for zero required tests", () => {
    expect(computeTestCoverage({ required_tests: 0, passing_tests: 0, failing_tests: 0, missing_tests: 0 })).toBe(1.0);
  });

  it("penalizes failing tests", () => {
    const score = computeTestCoverage({ required_tests: 10, passing_tests: 8, failing_tests: 2, missing_tests: 0 });
    expect(score).toBeLessThan(0.8);
  });
});

describe("computeContradictionPenalty", () => {
  it("returns 1.0 for no contradictions", () => {
    expect(computeContradictionPenalty({ contradictions: [] })).toBe(1.0);
  });

  it("returns 0 for critical contradiction", () => {
    expect(computeContradictionPenalty({ contradictions: [{ severity: "critical" }] })).toBe(0);
  });

  it("applies partial penalty for low severity", () => {
    const score = computeContradictionPenalty({ contradictions: [{ severity: "low" }] });
    expect(score).toBe(0.95);
  });
});
