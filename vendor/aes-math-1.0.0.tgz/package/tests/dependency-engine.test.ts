import { describe, it, expect } from "vitest";
import { analyzeDependencies, type DependencyNode } from "../src/engines/dependency-engine.js";

describe("analyzeDependencies", () => {
  it("handles empty node list", () => {
    const result = analyzeDependencies([]);
    expect(result.total_nodes).toBe(0);
    expect(result.completeness_score).toBe(1);
    expect(result.build_order).toHaveLength(0);
  });

  it("computes correct build order for linear chain", () => {
    const nodes: DependencyNode[] = [
      { id: "c", name: "C", status: "pending", dependencies: ["b"] },
      { id: "b", name: "B", status: "pending", dependencies: ["a"] },
      { id: "a", name: "A", status: "completed", dependencies: [] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.build_order).toEqual(["a", "b", "c"]);
  });

  it("detects missing prerequisites", () => {
    const nodes: DependencyNode[] = [
      { id: "a", name: "A", status: "pending", dependencies: ["missing-1", "missing-2"] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.missing_prerequisites).toHaveLength(2);
    expect(result.missing_prerequisites[0].missing_dep).toBe("missing-1");
  });

  it("detects circular dependencies", () => {
    const nodes: DependencyNode[] = [
      { id: "a", name: "A", status: "pending", dependencies: ["b"] },
      { id: "b", name: "B", status: "pending", dependencies: ["a"] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.circular_dependencies.length).toBeGreaterThan(0);
  });

  it("computes impact radius correctly", () => {
    const nodes: DependencyNode[] = [
      { id: "core", name: "Core", status: "completed", dependencies: [] },
      { id: "feat1", name: "Feat1", status: "pending", dependencies: ["core"] },
      { id: "feat2", name: "Feat2", status: "pending", dependencies: ["core"] },
      { id: "feat3", name: "Feat3", status: "pending", dependencies: ["feat1"] },
    ];
    const result = analyzeDependencies(nodes);
    const coreImpact = result.impact_map["core"];
    expect(coreImpact.direct_dependents).toContain("feat1");
    expect(coreImpact.direct_dependents).toContain("feat2");
    expect(coreImpact.total_impact).toBe(3); // feat1, feat2, feat3
  });

  it("finds critical path as longest chain", () => {
    const nodes: DependencyNode[] = [
      { id: "a", name: "A", status: "completed", dependencies: [] },
      { id: "b", name: "B", status: "pending", dependencies: ["a"] },
      { id: "c", name: "C", status: "pending", dependencies: ["b"] },
      { id: "d", name: "D", status: "pending", dependencies: [] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.critical_path.length).toBe(3);
    expect(result.critical_path.path).toEqual(["a", "b", "c"]);
  });

  it("reports blocking node in critical path", () => {
    const nodes: DependencyNode[] = [
      { id: "a", name: "A", status: "completed", dependencies: [] },
      { id: "b", name: "B", status: "blocked", dependencies: ["a"] },
      { id: "c", name: "C", status: "pending", dependencies: ["b"] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.critical_path.blocking_node).toBe("b");
    expect(result.critical_path.all_resolved).toBe(false);
  });

  it("computes completeness score", () => {
    const nodes: DependencyNode[] = [
      { id: "a", name: "A", status: "completed", dependencies: [] },
      { id: "b", name: "B", status: "completed", dependencies: [] },
      { id: "c", name: "C", status: "pending", dependencies: [] },
      { id: "d", name: "D", status: "pending", dependencies: [] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.completeness_score).toBe(0.5);
  });

  it("assigns risk levels based on impact", () => {
    const nodes: DependencyNode[] = [
      { id: "root", name: "Root", status: "completed", dependencies: [] },
      { id: "a", name: "A", status: "pending", dependencies: ["root"] },
      { id: "b", name: "B", status: "pending", dependencies: ["root"] },
      { id: "c", name: "C", status: "pending", dependencies: ["root"] },
      { id: "d", name: "D", status: "pending", dependencies: ["root"] },
      { id: "e", name: "E", status: "pending", dependencies: ["root"] },
      { id: "f", name: "F", status: "pending", dependencies: ["root"] },
    ];
    const result = analyzeDependencies(nodes);
    expect(result.impact_map["root"].risk_level).toBe("critical");
  });
});
