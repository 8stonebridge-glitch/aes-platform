import { describe, it, expect } from "vitest";
import { rankPriorities, type PriorityCandidate } from "../src/engines/priority-engine.js";

describe("rankPriorities", () => {
  it("ranks higher business value first", () => {
    const candidates: PriorityCandidate[] = [
      { id: "low", name: "Low", business_value: 0.3, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.5, is_blocked: false },
      { id: "high", name: "High", business_value: 0.9, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.5, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].id).toBe("high");
    expect(result[0].rank).toBe(1);
  });

  it("puts blocked items at the bottom", () => {
    const candidates: PriorityCandidate[] = [
      { id: "blocked", name: "Blocked", business_value: 1.0, readiness: 1.0, evidence_strength: 1.0, estimated_effort: 0, blast_radius: 0, is_blocked: true, blocking_reason: "test" },
      { id: "available", name: "Available", business_value: 0.1, readiness: 0.1, evidence_strength: 0.1, estimated_effort: 0.9, blast_radius: 0.9, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].id).toBe("available");
    expect(result[1].id).toBe("blocked");
    expect(result[1].score).toBe(0);
  });

  it("assigns sequential ranks", () => {
    const candidates: PriorityCandidate[] = [
      { id: "a", name: "A", business_value: 0.5, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.5, is_blocked: false },
      { id: "b", name: "B", business_value: 0.6, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.5, is_blocked: false },
      { id: "c", name: "C", business_value: 0.7, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.5, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].rank).toBe(1);
    expect(result[1].rank).toBe(2);
    expect(result[2].rank).toBe(3);
  });

  it("prefers lower effort (higher effort_inverse)", () => {
    const candidates: PriorityCandidate[] = [
      { id: "hard", name: "Hard", business_value: 0.5, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.9, blast_radius: 0.5, is_blocked: false },
      { id: "easy", name: "Easy", business_value: 0.5, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.1, blast_radius: 0.5, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].id).toBe("easy");
  });

  it("prefers lower blast radius", () => {
    const candidates: PriorityCandidate[] = [
      { id: "risky", name: "Risky", business_value: 0.5, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.9, is_blocked: false },
      { id: "safe", name: "Safe", business_value: 0.5, readiness: 0.5, evidence_strength: 0.5, estimated_effort: 0.5, blast_radius: 0.1, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].id).toBe("safe");
  });

  it("handles empty candidates", () => {
    const result = rankPriorities([]);
    expect(result).toHaveLength(0);
  });

  it("computes breakdown correctly", () => {
    const candidates: PriorityCandidate[] = [
      { id: "a", name: "A", business_value: 0.8, readiness: 0.6, evidence_strength: 0.7, estimated_effort: 0.3, blast_radius: 0.2, is_blocked: false },
    ];
    const result = rankPriorities(candidates);
    expect(result[0].breakdown.effort_inverse).toBe(0.7);
    expect(result[0].breakdown.blast_radius_inverse).toBe(0.8);
  });
});
