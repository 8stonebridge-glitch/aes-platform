import { describe, it, expect } from "vitest";
import { analyzeScopeDrift, type ScopeDefinition, type ActualChanges } from "../src/engines/scope-drift-engine.js";

function makeScope(): ScopeDefinition {
  return {
    allowed_paths: ["src/"],
    forbidden_paths: ["src/secrets/"],
    allowed_file_types: [".ts", ".tsx"],
    max_files_changed: 10,
    max_lines_changed: 500,
    may_create_files: true,
    may_delete_files: false,
    may_change_schema: false,
    may_change_shared_packages: false,
    may_change_config: false,
  };
}

function makeCleanChanges(): ActualChanges {
  return {
    files_created: ["src/new-file.ts"],
    files_modified: ["src/existing.ts"],
    files_deleted: [],
    total_lines_added: 50,
    total_lines_removed: 10,
    schema_changed: false,
    shared_packages_changed: false,
    config_changed: false,
  };
}

describe("analyzeScopeDrift", () => {
  it("returns clean for valid changes", () => {
    const result = analyzeScopeDrift(makeScope(), makeCleanChanges());
    expect(result.clean).toBe(true);
    expect(result.drift_score).toBe(0);
    expect(result.violations).toHaveLength(0);
  });

  it("detects path violations", () => {
    const changes = makeCleanChanges();
    changes.files_modified = ["lib/outside.ts"];
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.clean).toBe(false);
    expect(result.violations.some(v => v.type === "path_violation")).toBe(true);
  });

  it("detects forbidden paths", () => {
    const changes = makeCleanChanges();
    changes.files_modified = ["src/secrets/key.ts"];
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "forbidden_path")).toBe(true);
  });

  it("detects file type violations", () => {
    const changes = makeCleanChanges();
    changes.files_modified = ["src/readme.md"];
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "file_type_violation")).toBe(true);
  });

  it("detects unauthorized deletions", () => {
    const changes = makeCleanChanges();
    changes.files_deleted = ["src/old.ts"];
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "delete_violation")).toBe(true);
  });

  it("detects schema changes", () => {
    const changes = makeCleanChanges();
    changes.schema_changed = true;
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "schema_violation")).toBe(true);
  });

  it("detects file count exceeded", () => {
    const changes = makeCleanChanges();
    changes.files_modified = Array.from({ length: 11 }, (_, i) => `src/file${i}.ts`);
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "file_count_exceeded")).toBe(true);
    expect(result.within_budget).toBe(false);
  });

  it("detects line count exceeded", () => {
    const changes = makeCleanChanges();
    changes.total_lines_added = 600;
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.violations.some(v => v.type === "line_count_exceeded")).toBe(true);
  });

  it("computes drift score proportional to severity", () => {
    const changes = makeCleanChanges();
    changes.files_modified = ["lib/outside.ts"]; // critical
    changes.config_changed = true; // error
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.drift_score).toBeGreaterThan(0);
    expect(result.drift_score).toBeLessThanOrEqual(1);
  });

  it("caps drift score at 1", () => {
    const changes: ActualChanges = {
      files_created: ["lib/a.ts", "lib/b.ts", "lib/c.ts"],
      files_modified: ["lib/d.ts"],
      files_deleted: ["src/e.ts"],
      total_lines_added: 9999,
      total_lines_removed: 9999,
      schema_changed: true,
      shared_packages_changed: true,
      config_changed: true,
    };
    const result = analyzeScopeDrift(makeScope(), changes);
    expect(result.drift_score).toBeLessThanOrEqual(1);
  });
});
