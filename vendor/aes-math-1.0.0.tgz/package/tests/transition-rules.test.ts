import { describe, it, expect } from "vitest";
import { canTransition } from "../src/state/transition-rules.js";

describe("canTransition", () => {
  it("allows raw -> evidence_gathered with sufficient confidence", () => {
    const result = canTransition("raw", "evidence_gathered", { confidence: 0.2 });
    expect(result.allowed).toBe(true);
  });

  it("blocks raw -> evidence_gathered with zero confidence", () => {
    const result = canTransition("raw", "evidence_gathered", { confidence: 0 });
    expect(result.allowed).toBe(false);
  });

  it("allows evidence_gathered -> derived at 0.3 confidence without violations", () => {
    const result = canTransition("evidence_gathered", "derived", {
      confidence: 0.4,
      critical_violations: false,
    });
    expect(result.allowed).toBe(true);
  });

  it("blocks evidence_gathered -> derived with critical violations", () => {
    const result = canTransition("evidence_gathered", "derived", {
      confidence: 0.5,
      critical_violations: true,
    });
    expect(result.allowed).toBe(false);
  });

  it("blocks derived -> validated without required validators", () => {
    const result = canTransition("derived", "validated", {
      confidence: 0.6,
      vetoes_triggered: false,
      validators_passed: ["structure"],
    });
    expect(result.allowed).toBe(false);
    expect(result.reason).toContain("dependency_integrity");
  });

  it("allows derived -> validated with all required validators", () => {
    const result = canTransition("derived", "validated", {
      confidence: 0.6,
      vetoes_triggered: false,
      validators_passed: ["structure", "dependency_integrity"],
    });
    expect(result.allowed).toBe(true);
  });

  it("blocks validated -> promoted without full dependency completeness", () => {
    const result = canTransition("validated", "promoted", {
      confidence: 0.8,
      vetoes_triggered: false,
      critical_violations: false,
      dependency_completeness: 0.9,
      validators_passed: ["structure", "dependency_integrity", "scope_compliance", "interface_coverage", "rule_compliance", "test_mapping"],
    });
    expect(result.allowed).toBe(false);
  });

  it("blocks promoted -> execution_ready without human approval", () => {
    const result = canTransition("promoted", "execution_ready", {
      confidence: 0.8,
      vetoes_triggered: false,
      scope_drift: 0,
      human_approved: false,
    });
    expect(result.allowed).toBe(false);
    expect(result.reason).toContain("Human approval");
  });

  it("allows promoted -> execution_ready with human approval", () => {
    const result = canTransition("promoted", "execution_ready", {
      confidence: 0.8,
      vetoes_triggered: false,
      scope_drift: 0,
      human_approved: true,
    });
    expect(result.allowed).toBe(true);
  });

  it("blocks verified -> canonical below 0.85 confidence", () => {
    const result = canTransition("verified", "canonical", {
      confidence: 0.8,
      vetoes_triggered: false,
    });
    expect(result.allowed).toBe(false);
  });

  it("allows verified -> canonical at 0.85+ confidence", () => {
    const result = canTransition("verified", "canonical", {
      confidence: 0.9,
      vetoes_triggered: false,
    });
    expect(result.allowed).toBe(true);
  });

  it("allows rejection transitions unconditionally", () => {
    expect(canTransition("derived", "rejected", {}).allowed).toBe(true);
    expect(canTransition("validated", "rejected", {}).allowed).toBe(true);
    expect(canTransition("executed", "rejected", {}).allowed).toBe(true);
  });

  it("rejects unknown transitions", () => {
    const result = canTransition("raw", "canonical", {});
    expect(result.allowed).toBe(false);
    expect(result.reason).toContain("No transition rule");
  });
});
