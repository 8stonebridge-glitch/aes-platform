import { describe, it, expect } from "vitest";
import { validateStructure } from "../src/validators/structure-validator.js";
import { validateDependencyIntegrity } from "../src/validators/dependency-integrity-validator.js";
import { validateScopeCompliance } from "../src/validators/scope-compliance-validator.js";
import { validateInterfaceCoverage } from "../src/validators/interface-coverage-validator.js";
import { validateRuleCompliance } from "../src/validators/rule-compliance-validator.js";
import { validateTestMapping } from "../src/validators/test-mapping-validator.js";
import { runAllValidators, runValidator } from "../src/validators/validator-runner.js";

describe("validateStructure", () => {
  it("passes for valid artifact", () => {
    const result = validateStructure({
      artifact: { id: "a1", name: "Test", type: "feature", status: "raw", created_at: "2024-01-01", version: 1 },
    });
    expect(result.passed).toBe(true);
  });

  it("fails for null artifact", () => {
    const result = validateStructure({ artifact: null });
    expect(result.passed).toBe(false);
  });

  it("fails for missing required fields", () => {
    const result = validateStructure({ artifact: { id: "a1" } });
    expect(result.passed).toBe(false);
    expect(result.violations.some(v => v.code === "STRUCT_MISSING_FIELD")).toBe(true);
  });

  it("detects bridge mismatch", () => {
    const result = validateStructure({
      artifact: { id: "a1", name: "T", type: "f", status: "raw", created_at: "2024-01-01", version: 1 },
      bridge: { artifact_id: "WRONG", bridge_type: "test", created_at: "2024-01-01", confidence_score: 0.5 },
    });
    expect(result.violations.some(v => v.code === "STRUCT_BRIDGE_MISMATCH")).toBe(true);
  });

  it("detects invalid date", () => {
    const result = validateStructure({
      artifact: { id: "a1", name: "T", type: "f", status: "raw", created_at: "not-a-date", version: 1 },
    });
    expect(result.violations.some(v => v.code === "STRUCT_INVALID_DATE")).toBe(true);
  });
});

describe("validateDependencyIntegrity", () => {
  it("passes for artifact without dependencies", () => {
    const result = validateDependencyIntegrity({ artifact: { id: "a1", features: [] } });
    expect(result.passed).toBe(true);
  });

  it("detects circular dependencies in features", () => {
    const result = validateDependencyIntegrity({
      artifact: {
        id: "app",
        features: [
          { id: "f1", dependencies: ["f2"] },
          { id: "f2", dependencies: ["f1"] },
        ],
      },
    });
    expect(result.violations.some(v => v.code === "DEP_CIRCULAR")).toBe(true);
  });

  it("detects status mismatches", () => {
    const result = validateDependencyIntegrity({
      artifact: {
        id: "app",
        features: [
          { id: "f1", status: "completed", dependencies: ["f2"] },
          { id: "f2", status: "pending", dependencies: [] },
        ],
      },
    });
    expect(result.violations.some(v => v.code === "DEP_STATUS_MISMATCH")).toBe(true);
  });
});

describe("validateScopeCompliance", () => {
  it("passes when no scope provided", () => {
    const result = validateScopeCompliance({ artifact: {} });
    expect(result.passed).toBe(true);
  });

  it("detects scope violations", () => {
    const result = validateScopeCompliance({
      artifact: {},
      scope: {
        allowed_paths: ["src/"],
        forbidden_paths: [],
        allowed_file_types: [],
        max_files_changed: 10,
        max_lines_changed: 500,
        may_create_files: true,
        may_delete_files: true,
        may_change_schema: false,
        may_change_shared_packages: false,
        may_change_config: false,
      },
      actual_changes: {
        files_created: [],
        files_modified: ["lib/outside.ts"],
        files_deleted: [],
        total_lines_added: 10,
        total_lines_removed: 0,
        schema_changed: false,
        shared_packages_changed: false,
        config_changed: false,
      },
    });
    expect(result.passed).toBe(false);
  });
});

describe("validateInterfaceCoverage", () => {
  it("passes when no files", () => {
    const result = validateInterfaceCoverage({ artifact: {} });
    expect(result.passed).toBe(true);
  });

  it("detects any types in exports", () => {
    const result = validateInterfaceCoverage({
      artifact: {},
      files: [{
        path: "src/api.ts",
        content: 'export const thing: any = "hello";',
      }],
    });
    expect(result.violations.some(v => v.code === "IFACE_ANY_IN_PUBLIC")).toBe(true);
  });
});

describe("validateRuleCompliance", () => {
  it("passes when no bridge", () => {
    const result = validateRuleCompliance({ artifact: {} });
    expect(result.passed).toBe(true);
  });

  it("detects unaddressed required rules", () => {
    const result = validateRuleCompliance({
      artifact: {},
      bridge: {
        applied_rules: [
          { rule_id: "R1", description: "Evidence needed", required: true, gate_type: "coverage" },
        ],
      },
    });
    expect(result.violations.some(v => v.code === "RULE_UNADDRESSED")).toBe(true);
  });
});

describe("validateTestMapping", () => {
  it("passes when no required tests", () => {
    const result = validateTestMapping({ artifact: {} });
    expect(result.passed).toBe(true);
  });

  it("detects missing required tests", () => {
    const result = validateTestMapping({
      artifact: {},
      required_tests: ["test-auth", "test-payments"],
      actual_tests: ["test-auth"],
    });
    expect(result.violations.some(v => v.code === "TEST_MISSING")).toBe(true);
  });

  it("detects orphaned tests", () => {
    const result = validateTestMapping({
      artifact: {},
      required_tests: ["test-auth"],
      actual_tests: ["test-auth", "test-orphan"],
    });
    expect(result.violations.some(v => v.code === "TEST_ORPHANED")).toBe(true);
  });
});

describe("runAllValidators", () => {
  it("runs all 6 validators", () => {
    const result = runAllValidators({
      artifact: { id: "a1", name: "T", type: "f", status: "raw", created_at: "2024-01-01", version: 1 },
    });
    expect(result.total_validators).toBe(6);
  });

  it("aggregates scores", () => {
    const result = runAllValidators({
      artifact: { id: "a1", name: "T", type: "f", status: "raw", created_at: "2024-01-01", version: 1 },
    });
    expect(result.aggregate_score).toBeGreaterThan(0);
    expect(result.aggregate_score).toBeLessThanOrEqual(1);
  });
});

describe("runValidator", () => {
  it("returns error for unknown validator", () => {
    const result = runValidator("unknown", { artifact: {} });
    expect(result.passed).toBe(false);
    expect(result.violations[0].code).toBe("UNKNOWN_VALIDATOR");
  });

  it("runs named validator correctly", () => {
    const result = runValidator("structure", {
      artifact: { id: "a1", name: "T", type: "f", status: "raw", created_at: "2024-01-01", version: 1 },
    });
    expect(result.validator_name).toBe("structure");
    expect(result.passed).toBe(true);
  });
});
