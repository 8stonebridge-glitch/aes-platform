import { describe, it, expect } from "vitest";
import { evaluateVetoes, type VetoInput } from "../src/engines/veto-engine.js";

function makeCleanInput(): VetoInput {
  return {
    confidence_composite: 0.8,
    confidence_dimensions: { evidence: 0.8, deps: 0.8, tests: 0.8 },
    has_critical_contradictions: false,
    contradiction_count: 0,
    bridge_age_days: 1,
    max_bridge_age_days: 30,
    unresolved_dependencies: 0,
    scope_violations: [],
    missing_acceptance_tests: 0,
    total_acceptance_tests: 10,
    validator_failures: [],
    auth_defined: true,
    role_boundary_defined: true,
    tenancy_boundary_defined: true,
    destructive_actions_scoped: true,
    payment_reconciliation_defined: true,
    admin_role_bounded: true,
    external_api_fallback_defined: true,
    realtime_offline_defined: true,
    auditable_actions_logged: true,
    data_mutation_ownership_defined: true,
    all_feature_deps_exist: true,
  };
}

describe("evaluateVetoes", () => {
  it("returns no vetoes for clean input", () => {
    const result = evaluateVetoes(makeCleanInput());
    expect(result.any_triggered).toBe(false);
    expect(result.triggered_count).toBe(0);
    expect(result.blocking_codes).toHaveLength(0);
  });

  it("triggers VETO_CONFIDENCE_BELOW_MINIMUM", () => {
    const input = makeCleanInput();
    input.confidence_composite = 0.1;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_CONFIDENCE_BELOW_MINIMUM");
  });

  it("triggers VETO_ZERO_DIMENSION", () => {
    const input = makeCleanInput();
    input.confidence_dimensions = { evidence: 0, deps: 0.8 };
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_ZERO_DIMENSION");
  });

  it("triggers VETO_CRITICAL_CONTRADICTION", () => {
    const input = makeCleanInput();
    input.has_critical_contradictions = true;
    input.contradiction_count = 2;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_CRITICAL_CONTRADICTION");
  });

  it("triggers VETO_STALE_BRIDGE", () => {
    const input = makeCleanInput();
    input.bridge_age_days = 31;
    input.max_bridge_age_days = 30;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_STALE_BRIDGE");
  });

  it("triggers VETO_MISSING_DEPENDENCY", () => {
    const input = makeCleanInput();
    input.unresolved_dependencies = 3;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_MISSING_DEPENDENCY");
  });

  it("triggers VETO_SCOPE_VIOLATION", () => {
    const input = makeCleanInput();
    input.scope_violations = ["changed /etc/config"];
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_SCOPE_VIOLATION");
  });

  it("triggers VETO_MISSING_ACCEPTANCE_TESTS when > 50% missing", () => {
    const input = makeCleanInput();
    input.missing_acceptance_tests = 6;
    input.total_acceptance_tests = 10;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_MISSING_ACCEPTANCE_TESTS");
  });

  it("does NOT trigger VETO_MISSING_ACCEPTANCE_TESTS when <= 50% missing", () => {
    const input = makeCleanInput();
    input.missing_acceptance_tests = 4;
    input.total_acceptance_tests = 10;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).not.toContain("VETO_MISSING_ACCEPTANCE_TESTS");
  });

  it("triggers VETO_AUTH_NOT_DEFINED", () => {
    const input = makeCleanInput();
    input.auth_defined = false;
    const result = evaluateVetoes(input);
    expect(result.blocking_codes).toContain("VETO_AUTH_NOT_DEFINED");
  });

  it("triggers all v12 vetoes simultaneously", () => {
    const input = makeCleanInput();
    input.auth_defined = false;
    input.role_boundary_defined = false;
    input.tenancy_boundary_defined = false;
    input.destructive_actions_scoped = false;
    input.payment_reconciliation_defined = false;
    input.admin_role_bounded = false;
    input.external_api_fallback_defined = false;
    input.realtime_offline_defined = false;
    input.auditable_actions_logged = false;
    input.data_mutation_ownership_defined = false;
    input.all_feature_deps_exist = false;
    const result = evaluateVetoes(input);
    expect(result.triggered_count).toBeGreaterThanOrEqual(11);
  });

  it("always returns 19 results", () => {
    const result = evaluateVetoes(makeCleanInput());
    expect(result.results).toHaveLength(19);
  });
});
